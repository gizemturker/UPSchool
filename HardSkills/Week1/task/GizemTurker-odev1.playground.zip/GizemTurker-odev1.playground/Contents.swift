import UIKit

// Table-1

var processNumber:Int = 7554
print("Process number is \(processNumber)")

var studentNumber = 10243073
print("Student number is \(studentNumber)")

// Int---> String Çevirme
var studentNumberText = String(studentNumber)

var bookNumber:Int = 123
print(bookNumber)

let firstDate:String = "12.02.2021"
print("first date is \(firstDate)")

let lastDate:String = "15.03.2021"
print("last date is \(lastDate)")

//Table-2

var student_number = 1811054
var student_name = "Gizem"
var student_surname = "Türker"
let gender = "bekar"
let b_date = "02.10.1991"
var class_number = 3
print("Student number is \(student_number), Student name is \(student_name) \(student_surname), Her birthday is \(b_date) and Her class is \(class_number)")

// Table-3

var book_number = 167
var isbn_number:String = "768-767-9807-8-8"
var book_name = "Moby Dick"
let author_name = "Herman Melville"
var page_t = 153
var score = 18

print("Book number is \(book_number), book isbn is \(isbn_number), book name is \(book_name), author name is \(author_name), total page is \(page_t) and score is \(score)")

// Table 5'dekiler yukarıda yapılmıştır.

var sprint_number = 345
let sprint_name = "Local"

print("Sprint number is \(sprint_number) and name is \(sprint_name)")








